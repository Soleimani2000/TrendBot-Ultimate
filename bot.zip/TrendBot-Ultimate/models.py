from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

# ====================== مدل‌های نهایی TrendBot Ultimate v21.0 ======================

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    username = db.Column(db.String(50), unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(100), default='')
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # روابط
    accounts = db.relationship('Account', backref='user', lazy=True)
    hashtags = db.relationship('Hashtag', backref='user', lazy=True)
    likes = db.relationship('Like', backref='user', lazy=True)
    retweets = db.relationship('Retweet', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    full_name = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # ←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←
    email = db.Column(db.String(150), nullable=True)      # ← حتماً این خط باشه
    password = db.Column(db.String(200), nullable=True)   # ← حتماً این خط باشه
    # ←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←

    # بقیه فیلدها...
    api_key = db.Column(db.String(200))
    api_secret = db.Column(db.String(200))
    access_token = db.Column(db.String(200))
    access_token_secret = db.Column(db.String(200))
    bearer_token = db.Column(db.String(300))
    
    likes_today = db.Column(db.Integer, default=0)
    retweets_today = db.Column(db.Integer, default=0)
    last_like_date = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(20), default='unknown')
    last_checked = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Hashtag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hashtag = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.String(50), nullable=False)
    hashtag = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Retweet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.String(50), nullable=False)
    hashtag = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# تنظیمات مرکزی (فقط یک ردیف در کل سیستم)
class BotSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    max_likes_per_day = db.Column(db.Integer, nullable=False)
    like_delay_min = db.Column(db.Integer, nullable=False)
    like_delay_max = db.Column(db.Integer, nullable=False)
    max_retweets_per_day = db.Column(db.Integer, nullable=False)
    retweet_delay_min = db.Column(db.Integer, nullable=False)
    retweet_delay_max = db.Column(db.Integer, nullable=False)