from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from models import Account, db

accounts_bp = Blueprint('accounts', __name__, template_folder='../templates')

@accounts_bp.route('/accounts')
@login_required
def accounts():
    user_accounts = Account.query.filter_by(user_id=current_user.id).all()
    return render_template('accounts.html', accounts=user_accounts)

@accounts_bp.route('/account/add', methods=['GET', 'POST'])
@login_required
def account_add():
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lstrip('@')
        full_name = request.form.get('full_name', '').strip()
        
        if not username:
            flash('نام کاربری الزامی است!', 'error')
            return redirect(url_for('accounts.account_add'))
            
        # چک تکراری بودن
        if Account.query.filter_by(username=username).first():
            flash('این اکانت قبلاً اضافه شده است!', 'error')
            return redirect(url_for('accounts.account_add'))
            
        new_account = Account(
            username=username,
            full_name=full_name or username,
            user_id=current_user.id,
            is_active=True
        )
        db.session.add(new_account)
        db.session.commit()
        
        flash(f'اکانت @{username} با موفقیت اضافه شد!', 'success')
        return redirect(url_for('accounts.accounts'))
    
    return render_template('account_add.html')
    
@accounts_bp.route('/account/delete/<int:account_id>', methods=['POST'])
@login_required
def account_delete(account_id):
    account = Account.query.get_or_404(account_id)
    if account.user_id != current_user.id:
        flash('شما اجازه حذف این اکانت را ندارید!', 'error')
        return redirect(url_for('accounts.accounts'))
        
    db.session.delete(account)
    db.session.commit()
    flash('اکانت با موفقیت حذف شد!', 'success')
    return redirect(url_for('accounts.accounts'))