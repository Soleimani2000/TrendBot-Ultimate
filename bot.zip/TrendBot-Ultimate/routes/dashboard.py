from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required
from models import Account, Hashtag
from database import db
import json
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@login_required
def index():
    """Main dashboard page"""
    try:
        # Get statistics
        accounts = Account.query.filter_by(is_active=True).count()
        total_accounts = Account.query.count()
        hashtags = Hashtag.query.count()
        
        # Recent activity (mock data)
        recent_activity = [
            {
                'account': '@account1',
                'action': 'لایک',
                'hashtag': '#ایران',
                'time': '2 دقیقه پیش',
                'success': True
            },
            {
                'account': '@account2', 
                'action': 'ریتوییت',
                'hashtag': '#تهران',
                'time': '5 دقیقه پیش',
                'success': True
            }
        ]
        
        stats = {
            'accounts': accounts,
            'total_accounts': total_accounts,
            'likes': 247,
            'retweets': 89,
            'total': 336,
            'hashtags': hashtags
        }
        
        return render_template('dashboard.html', stats=stats, recent_activity=recent_activity)
        
    except Exception as e:
        flash(f'خطا در بارگذاری داشبورد: {str(e)}', 'error')
        return render_template('dashboard.html', stats={}, recent_activity=[])

@dashboard_bp.route('/api/bot/status')
@login_required
def bot_status():
    """Get bot status"""
    try:
        # Mock bot status - in real implementation read from Redis or file
        status = {
            'running': True,
            'uptime': '2h 47m',
            'last_run': '14:32:17',
            'cycles': 247,
            'next_run': '14:37:00'
        }
        
        return jsonify({
            'success': True,
            'data': status
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/api/bot/toggle', methods=['POST'])
@login_required
def toggle_bot():
    """Toggle bot on/off"""
    try:
        data = request.get_json()
        running = data.get('running', False)
        
        # In real implementation: write to control file or Redis
        # For demo, just return success
        status = 'شروع شد' if running else 'متوقف شد'
        
        return jsonify({
            'success': True,
            'message': f'بات {status} ✅'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500