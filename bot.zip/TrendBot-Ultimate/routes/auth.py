from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from models import User
from database import db
import logging

auth_bp = Blueprint('auth', __name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login endpoint"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        
        # Validate input
        if not email or not password:
            flash('ایمیل و رمز عبور الزامی است', 'error')
            return render_template('login.html')
        
        try:
            # Find user
            user = User.query.filter_by(email=email).first()
            
            if user and check_password_hash(user.password, password):
                login_user(user)
                logger.info(f"User {email} logged in successfully")
                flash('با موفقیت وارد شدید! 🚀', 'success')
                return redirect(url_for('dashboard'))
            else:
                logger.warning(f"Failed login attempt for {email}")
                flash('ایمیل یا رمز عبور اشتباه است', 'error')
                
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            flash('خطا در ورود. لطفاً دوباره تلاش کنید', 'error')
    
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    """User logout endpoint"""
    try:
        logout_user()
        logger.info(f"User {current_user.email} logged out")
        flash('با موفقیت خارج شدید', 'success')
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
    
    return redirect(url_for('auth.login'))

@auth_bp.route('/api/stats')
def get_stats():
    """API endpoint for dashboard statistics"""
    try:
        from models import Account
        
        stats = {
            'accounts': Account.query.filter_by(is_active=True).count(),
            'likes': Account.query.with_entities(db.func.sum(Account.likes_today)).scalar() or 0,
            'retweets': Account.query.with_entities(db.func.sum(Account.retweets_today)).scalar() or 0,
            'total': 0,
            'hashtags': 15,  # Placeholder
            'uptime': '2h 47m'
        }
        
        stats['total'] = stats['likes'] + stats['retweets']
        
        return {
            'success': True,
            'data': stats
        }
        
    except Exception as e:
        logger.error(f"Stats API error: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }, 500