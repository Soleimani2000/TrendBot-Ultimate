from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models import Hashtag
from database import db

hashtags_bp = Blueprint('hashtags', __name__)

@hashtags_bp.route('/')
@login_required
def hashtags():
    hashtags = Hashtag.query.all()
    return render_template('hashtags.html', hashtags=hashtags)

@hashtags_bp.route('/add', methods=['POST'])
@login_required
def hashtag_add():
    tag = request.form['tag'].strip().lstrip('#')
    max_likes = int(request.form.get('max_likes', 100))
    max_retweets = int(request.form.get('max_retweets', 50))
    
    if tag:
        existing = Hashtag.query.filter_by(tag=tag).first()
        if not existing:
            new_hashtag = Hashtag(tag=tag, max_likes=max_likes, max_retweets=max_retweets)
            db.session.add(new_hashtag)
            db.session.commit()
            flash('هشتگ با موفقیت اضافه شد!', 'success')
    return redirect(url_for('hashtags.hashtags'))