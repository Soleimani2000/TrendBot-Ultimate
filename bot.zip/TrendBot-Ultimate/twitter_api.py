import tweepy
import os
import logging
from datetime import datetime
from models import ProcessedTweet, TwitterAccount
import time
import random

logger = logging.getLogger(__name__)

class TwitterAPIClient:
    def __init__(self, account: TwitterAccount):
        self.account = account
        self.client = self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Twitter API client"""
        try:
            client = tweepy.Client(
                bearer_token=os.getenv('TWITTER_BEARER_TOKEN'),
                consumer_key=os.getenv('TW_CONSUMER_KEY'),
                consumer_secret=os.getenv('TW_CONSUMER_SECRET'),
                access_token=self.account.access_token,
                access_token_secret=self.account.access_token_secret,
                wait_on_rate_limit=True
            )
            return client
        except Exception as e:
            logger.error(f"Failed to initialize Twitter client: {e}")
            return None
    
    def search_recent_tweets(self, hashtags, max_results=10):
        """Search for recent tweets with hashtags"""
        if not self.client:
            return []
        
        tweets = []
        for hashtag in hashtags:
            try:
                query = f"#{hashtag} lang:fa -is:retweet"
                response = self.client.search_recent_tweets(
                    query=query,
                    max_results=5,
                    tweet_fields=['id', 'author_id', 'created_at']
                )
                
                if response.data:
                    for tweet in response.data:
                        tweet_id = str(tweet.id)
                        # Check if already processed
                        existing = ProcessedTweet.query.filter_by(
                            tweet_id=tweet_id,
                            account_id=self.account.id
                        ).first()
                        
                        if not existing:
                            tweets.append({
                                'id': tweet_id,
                                'hashtag': hashtag
                            })
                
                time.sleep(2)  # Rate limit
                
            except Exception as e:
                logger.error(f"Search error for #{hashtag}: {e}")
                continue
        
        return tweets[:max_results]
    
    def like_tweet(self, tweet_id, hashtag):
        """Like a tweet"""
        if not self.client:
            return False
        
        try:
            self.client.like(tweet_id)
            
            # Log success
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=self.account.id,
                hashtag=hashtag,
                action='like',
                success=True
            )
            db.session.add(processed)
            self.account.likes_today += 1
            self.account.last_active = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"❤️ Like successful: {tweet_id}")
            return True
            
        except Exception as e:
            logger.error(f"Like failed: {e}")
            # Log failure
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=self.account.id,
                hashtag=hashtag,
                action='like',
                success=False,
                error_message=str(e)
            )
            db.session.add(processed)
            db.session.commit()
            return False
    
    def retweet_tweet(self, tweet_id, hashtag):
        """Retweet a tweet"""
        if not self.client:
            return False
        
        try:
            self.client.retweet(tweet_id)
            
            # Log success
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=self.account.id,
                hashtag=hashtag,
                action='retweet',
                success=True
            )
            db.session.add(processed)
            self.account.retweets_today += 1
            self.account.last_active = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"🔄 Retweet successful: {tweet_id}")
            return True
            
        except Exception as e:
            logger.error(f"Retweet failed: {e}")
            # Log failure
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=self.account.id,
                hashtag=hashtag,
                action='retweet',
                success=False,
                error_message=str(e)
            )
            db.session.add(processed)
            db.session.commit()
            return False