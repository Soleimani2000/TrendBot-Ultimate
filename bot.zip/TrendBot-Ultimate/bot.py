import time
import random
import logging
from datetime import datetime
from app import app, db, Account, Hashtag
from tweepy import Client
import os

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler('logs/bot/bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TwitterBot:
    def __init__(self):
        self.running = False
        self.cycle_count = 0
        
    def get_active_accounts(self):
        """Get active Twitter accounts"""
        with app.app_context():
            return Account.query.filter_by(is_active=True).all()
    
    def get_active_hashtags(self):
        """Get active hashtags"""
        with app.app_context():
            return Hashtag.query.filter_by(is_active=True).all()
    
    def create_twitter_client(self, account):
        """Create Twitter client for account"""
        try:
            client = Client(
                consumer_key=os.getenv('TWITTER_API_KEY', 'test_key'),
                consumer_secret=os.getenv('TWITTER_API_SECRET', 'test_secret'),
                access_token=account.access_token,
                access_token_secret=account.access_token_secret,
                wait_on_rate_limit=True
            )
            return client
        except Exception as e:
            logger.error(f"❌ Twitter client error for {account.username}: {e}")
            return None
    
    def perform_actions(self, client, hashtag, account):
        """Perform like and retweet actions"""
        try:
            # Search tweets
            tweets = client.search_recent_tweets(
                query=f"#{hashtag.tag} -is:retweet lang:fa",
                max_results=10
            )
            
            if not tweets.data:
                return
            
            # Randomly select tweets
            selected_tweets = random.sample(tweets.data, min(3, len(tweets.data)))
            
            for tweet in selected_tweets:
                if account.likes_today >= account.max_likes_per_day:
                    break
                
                try:
                    # Like
                    client.like(tweet.id)
                    account.likes_today += 1
                    logger.info(f"❤️ {account.name} liked tweet {tweet.id} for #{hashtag.tag}")
                    
                    # Random delay
                    time.sleep(random.uniform(2, 5))
                    
                    # Retweet (less frequent)
                    if (account.retweets_today < account.max_retweets_per_day and 
                        random.random() < 0.3):
                        client.retweet(tweet.id)
                        account.retweets_today += 1
                        logger.info(f"🔄 {account.name} retweeted tweet {tweet.id} for #{hashtag.tag}")
                        
                except Exception as e:
                    logger.error(f"❌ Action failed: {e}")
            
            # Save to database
            with app.app_context():
                db.session.commit()
                
        except Exception as e:
            logger.error(f"💥 Bot action error: {e}")
    
    def run_cycle(self):
        """Run one complete cycle"""
        self.cycle_count += 1
        logger.info(f"🚀 دور {self.cycle_count} شروع شد")
        
        accounts = self.get_active_accounts()
        hashtags = self.get_active_hashtags()
        
        if not accounts or not hashtags:
            logger.warning("⚠️  هیچ اکانت یا هشتگ فعالی پیدا نشد")
            return False
        
        logger.info(f"👥 اکانت‌های فعال: {len(accounts)}")
        logger.info(f"🏷️ هشتگ‌های فعال: {len(hashtags)}")
        
        total_actions = 0
        
        for account in accounts:
            for hashtag in hashtags:
                if (account.likes_today >= account.max_likes_per_day or 
                    account.retweets_today >= account.max_retweets_per_day):
                    logger.info(f"⏸️  {account.name} به حد مجاز رسید")
                    continue
                
                client = self.create_twitter_client(account)
                if client:
                    self.perform_actions(client, hashtag, account)
                    total_actions += 1
                
                # Random delay between accounts
                time.sleep(random.uniform(10, 30))
        
        logger.info(f"✅ دور {self.cycle_count} کامل شد - {total_actions} عملیات")
        return True
    
    def start(self):
        """Start the bot"""
        self.running = True
        logger.info("🤖 Twitter Bot Started")
        logger.info("⏰ هر 5 دقیقه یک دور کامل")
        
        while self.running:
            try:
                success = self.run_cycle()
                if success:
                    # Wait 5 minutes (300 seconds)
                    logger.info("⏳ منتظر دور بعدی (5 دقیقه)...")
                    time.sleep(300)
                else:
                    logger.warning("⚠️  دور ناموفق - 1 دقیقه صبر")
                    time.sleep(60)
                    
            except KeyboardInterrupt:
                logger.info("🛑 بات متوقف شد")
                self.running = False
                break
            except Exception as e:
                logger.error(f"💥 خطای غیرمنتظره: {e}")
                time.sleep(30)

if __name__ == '__main__':
    bot = TwitterBot()
    bot.start()
