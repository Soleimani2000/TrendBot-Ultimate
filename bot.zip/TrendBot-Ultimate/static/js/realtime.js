// Real-time Activity Feed & WebSocket Implementation
class RealTimeActivity {
    constructor() {
        this.ws = null;
        this.activities = [];
        this.maxActivities = 50;
        this.init();
    }

    init() {
        this.connectWebSocket();
        this.setupActivityFeed();
        this.startAutoRefresh();
    }

    connectWebSocket() {
        // Fallback to Server-Sent Events if WebSocket not available
        if (typeof EventSource !== 'undefined') {
            this.useSSE();
        } else {
            this.useWebSocket();
        }
    }

    useSSE() {
        const eventSource = new EventSource('/api/events');
        
        eventSource.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.addActivity(data);
        };

        eventSource.onerror = () => {
            console.warn('SSE connection lost, reconnecting...');
            setTimeout(() => this.connectWebSocket(), 3000);
        };

        this.eventSource = eventSource;
    }

    useWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
        
        this.ws.onopen = () => {
            console.log('✅ WebSocket connected');
            this.ws.send(JSON.stringify({ type: 'join', channel: 'bot_activity' }));
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleWebSocketMessage(data);
        };

        this.ws.onclose = () => {
            console.warn('WebSocket disconnected, reconnecting...');
            setTimeout(() => this.connectWebSocket(), 3000);
        };
    }

    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'activity':
                this.addActivity(data.activity);
                break;
            case 'stats_update':
                this.updateStats(data.stats);
                break;
            case 'bot_status':
                this.updateBotStatus(data.status);
                break;
        }
    }

    addActivity(activity) {
        const activityElement = this.createActivityElement(activity);
        
        const feed = document.getElementById('activity-feed');
        if (feed) {
            feed.insertBefore(activityElement, feed.firstChild);
            
            // Keep only maxActivities
            while (feed.children.length > this.maxActivities) {
                feed.removeChild(feed.lastChild);
            }
        }

        // Auto-scroll to top
        feed.scrollTop = 0;

        // Remove after 5 minutes
        setTimeout(() => {
            if (activityElement.parentNode) {
                activityElement.classList.add('fade-out');
                setTimeout(() => {
                    if (activityElement.parentNode) {
                        activityElement.parentNode.removeChild(activityElement);
                    }
                }, 500);
            }
        }, 300000); // 5 minutes
    }

    createActivityElement(activity) {
        const div = document.createElement('div');
        div.className = `activity-item flex items-center justify-between p-4 rounded-xl transition-all duration-300 ${
            activity.success 
                ? 'bg-gradient-to-r from-green-500/10 to-green-600/10 border-r-4 border-green-500/30' 
                : 'bg-gradient-to-r from-red-500/10 to-red-600/10 border-r-4 border-red-500/30'
        }`;

        const timeAgo = this.formatTimeAgo(activity.timestamp);
        const emoji = activity.action === 'like' ? '❤️' : '🔄';
        const statusEmoji = activity.success ? '✅' : '❌';

        div.innerHTML = `
            <div class="flex items-center space-x-4 space-x-reverse flex-1 min-w-0">
                <div class="flex-shrink-0 w-10 h-10 bg-gradient-to-br ${
                    activity.success ? 'from-green-500/20 to-green-600/20' : 'from-red-500/20 to-red-600/20'
                } rounded-full flex items-center justify-center">
                    <span class="text-lg">${emoji}</span>
                </div>
                <div class="min-w-0 flex-1">
                    <p class="font-semibold text-white truncate" title="${activity.account} ${activity.action} کرد">
                        <span class="font-medium">${activity.account}</span> 
                        ${activity.action === 'like' ? 'لایک' : 'ریتوییت'} کرد
                    </p>
                    <p class="text-sm text-gray-400 truncate" title="${activity.hashtag}">
                        <span class="font-mono">${activity.hashtag}</span>
                    </p>
                </div>
                <div class="flex items-center space-x-2 space-x-reverse flex-shrink-0">
                    <span class="text-xs font-mono text-gray-500">${timeAgo}</span>
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        activity.success 
                            ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }">
                        ${statusEmoji}
                    </span>
                </div>
            </div>
        `;

        return div;
    }

    updateStats(stats) {
        // Update global stats
        const likesEl = document.getElementById('global-likes');
        const retweetsEl = document.getElementById('global-retweets');
        const totalEl = document.getElementById('global-total');

        if (likesEl) likesEl.textContent = stats.likes.toLocaleString();
        if (retweetsEl) retweetsEl.textContent = stats.retweets.toLocaleString();
        if (totalEl) totalEl.textContent = stats.total.toLocaleString();
    }

    updateBotStatus(status) {
        const statusEl = document.getElementById('bot-status');
        const toggleBtn = document.getElementById('bot-toggle');
        
        if (statusEl) {
            if (status.running) {
                statusEl.innerHTML = `
                    <div class="flex items-center">
                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3 animate-pulse"></div>
                        <span class="font-semibold text-green-400">فعال</span>
                        <span class="ml-2 text-sm text-green-300">${status.uptime} ساعت</span>
                    </div>
                `;
            } else {
                statusEl.innerHTML = `
                    <div class="flex items-center">
                        <div class="w-3 h-3 bg-red-500 rounded-full mr-3 animate-pulse"></div>
                        <span class="font-semibold text-red-400">متوقف</span>
                    </div>
                `;
            }
        }
    }

    formatTimeAgo(timestamp) {
        const now = new Date();
        const activityTime = new Date(timestamp);
        const diffMs = now - activityTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffSecs = Math.floor(diffMs / 1000);

        if (diffMins < 1) {
            return `${diffSecs}ثانیه پیش`;
        } else if (diffMins < 60) {
            return `${diffMins}دقیقه پیش`;
        } else {
            const diffHours = Math.floor(diffMins / 60);
            return `${diffHours}ساعت پیش`;
        }
    }

    setupActivityFeed() {
        const feed = document.getElementById('activity-feed');
        if (feed) {
            // Add smooth scroll
            feed.addEventListener('scroll', () => {
                feed.classList.add('scrolling');
                setTimeout(() => {
                    feed.classList.remove('scrolling');
                }, 1000);
            });
        }
    }

    startAutoRefresh() {
        // Refresh bot status every 30 seconds
        setInterval(() => {
            fetch('/api/bot/status')
                .then(response => response.json())
                .then(status => this.updateBotStatus(status));
        }, 30000);
    }

    // Cleanup
    disconnect() {
        if (this.ws) {
            this.ws.close();
        }
        if (this.eventSource) {
            this.eventSource.close();
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.realTimeActivity = new RealTimeActivity();
    
    // Handle page unload
    window.addEventListener('beforeunload', () => {
        if (window.realTimeActivity) {
            window.realTimeActivity.disconnect();
        }
    });
});

// Auto-reconnect on network recovery
window.addEventListener('online', () => {
    console.log('🌐 Network reconnected');
    setTimeout(() => {
        if (window.realTimeActivity) {
            window.realTimeActivity.connectWebSocket();
        }
    }, 1000);
});