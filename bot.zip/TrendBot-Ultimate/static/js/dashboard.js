// Dashboard Real-time Updates & Interactions
class DashboardManager {
    constructor() {
        this.statsInterval = null;
        this.activityInterval = null;
        this.init();
    }

    init() {
        this.startRealTimeStats();
        this.setupQuickActions();
        this.setupBotControls();
        this.setupCharts();
        this.animateCounters();
    }

    // Real-time Statistics Update
    startRealTimeStats() {
        this.statsInterval = setInterval(async () => {
            try {
                const response = await fetch('/api/stats');
                const stats = await response.json();
                
                this.updateStatCounter('likes-count', stats.likes);
                this.updateStatCounter('retweets-count', stats.retweets);
                this.updateStatCounter('total-count', stats.total);
                
                // Update progress bars
                this.updateProgressBars(stats);
                
            } catch (error) {
                console.error('Error updating stats:', error);
            }
        }, 5000);
    }

    updateStatCounter(elementId, targetValue) {
        const element = document.getElementById(elementId);
        if (!element) return;

        const currentValue = parseInt(element.textContent.replace(/[^\d]/g, '')) || 0;
        const increment = targetValue > currentValue ? 1 : -1;
        const duration = 1000; // 1 second
        const steps = Math.abs(targetValue - currentValue);
        const delay = duration / steps;

        let current = currentValue;
        const timer = setInterval(() => {
            current += increment;
            element.textContent = current.toLocaleString();
            
            if (current === targetValue) {
                clearInterval(timer);
            }
        }, delay);
    }

    updateProgressBars(stats) {
        // Update account progress bars
        document.querySelectorAll('.account-progress').forEach(bar => {
            const max = parseInt(bar.dataset.max);
            const current = parseInt(bar.dataset.current);
            const percentage = (current / max) * 100;
            bar.style.width = `${Math.min(percentage, 100)}%`;
        });
    }

    // Quick Actions
    setupQuickActions() {
        document.querySelectorAll('.quick-action').forEach(action => {
            action.addEventListener('click', function() {
                const type = this.dataset.action;
                const icon = this.querySelector('.quick-action-icon');
                
                // Add loading state
                const originalText = this.innerHTML;
                this.innerHTML = `
                    <div class="flex items-center justify-center space-x-2 space-x-reverse">
                        <div class="loading-spinner w-5 h-5"></div>
                        <span class="text-sm">در حال پردازش...</span>
                    </div>
                `;
                
                // Simulate API call
                setTimeout(() => {
                    this.innerHTML = originalText;
                    
                    // Show notification
                    this.showNotification(`${type} با موفقیت انجام شد!`, 'success');
                    
                    // Add success animation
                    this.classList.add('animate-pulse');
                    setTimeout(() => {
                        this.classList.remove('animate-pulse');
                    }, 1000);
                }, 2000);
            });
        });
    }

    // Bot Controls
    setupBotControls() {
        const botToggle = document.getElementById('bot-toggle');
        if (botToggle) {
            botToggle.addEventListener('click', () => {
                const isRunning = botToggle.classList.contains('bg-green-600');
                
                fetch('/api/bot/toggle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ running: !isRunning })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (!isRunning) {
                            botToggle.classList.remove('bg-red-600', 'text-white');
                            botToggle.classList.add('bg-green-600', 'text-white');
                            botToggle.innerHTML = `
                                <span class="mr-2">🟢</span>
                                توقف بات
                            `;
                            this.showNotification('✅ بات با موفقیت شروع شد', 'success');
                        } else {
                            botToggle.classList.remove('bg-green-600', 'text-white');
                            botToggle.classList.add('bg-red-600', 'text-white');
                            botToggle.innerHTML = `
                                <span class="mr-2">🔴</span>
                                شروع بات
                            `;
                            this.showNotification('⏹️ بات با موفقیت متوقف شد', 'info');
                        }
                    }
                });
            });
        }
    }

    // Charts Initialization
    setupCharts() {
        // Initialize any dashboard charts
        this.initActivityChart();
        this.initPerformanceChart();
    }

    initActivityChart() {
        // Real-time activity chart
        const ctx = document.getElementById('activity-chart')?.getContext('2d');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'تعاملات',
                        data: [],
                        borderColor: '#a855f7',
                        backgroundColor: 'rgba(168, 85, 247, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true },
                        x: { display: false }
                    },
                    animation: {
                        duration: 1000,
                        easing: 'easeInOutQuart'
                    }
                }
            });
        }
    }

    // Counter Animation
    animateCounters() {
        const counters = document.querySelectorAll('.counter-animate');
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const increment = target / 50;
            let current = 0;

            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                counter.textContent = Math.floor(current).toLocaleString();
            }, 30);
        });
    }

    // Notification System
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${
            type === 'success' ? 'border-green-500/30 bg-green-500/10 text-green-300' :
            type === 'error' ? 'border-red-500/30 bg-red-500/10 text-red-300' :
            type === 'warning' ? 'border-yellow-500/30 bg-yellow-500/10 text-yellow-300' :
            'border-blue-500/30 bg-blue-500/10 text-blue-300'
        }`;
        
        notification.innerHTML = `
            <div class="flex items-center">
                ${type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️'}
                <span class="mr-3">${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 4 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }

    // Cleanup
    destroy() {
        if (this.statsInterval) clearInterval(this.statsInterval);
        if (this.activityInterval) clearInterval(this.activityInterval);
    }
}

// Initialize Dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new DashboardManager();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 'r':
                    e.preventDefault();
                    location.reload();
                    break;
                case 's':
                    e.preventDefault();
                    // Trigger save action
                    break;
            }
        }
    });
});

// Handle page visibility change
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        // Refresh data when user returns to tab
        if (window.dashboard) {
            window.dashboard.startRealTimeStats();
        }
    }
});