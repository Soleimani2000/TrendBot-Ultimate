// TrendBot Ultimate - Advanced Charts & Analytics
class ChartsManager {
    constructor() {
        this.charts = {};
        this.init();
    }

    init() {
        this.initInteractionsChart();
        this.initPerformanceChart();
        this.initHashtagChart();
        this.initAccountPerformance();
        this.startRealTimeUpdates();
    }

    // Interactions Over Time Chart
    initInteractionsChart() {
        const ctx = document.getElementById('interactions-chart');
        if (!ctx) return;

        this.charts.interactions = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
                datasets: [{
                    label: 'تعاملات',
                    data: [120, 180, 250, 320, 280, 350],
                    borderColor: '#a855f7',
                    backgroundColor: 'rgba(168, 85, 247, 0.1)',
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#a855f7',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        cornerRadius: 12
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        ticks: { color: '#9ca3af', font: { size: 12 } }
                    },
                    x: {
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        ticks: { color: '#9ca3af', font: { size: 12 } }
                    }
                },
                animation: {
                    duration: 2000,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }

    // Performance Doughnut Chart
    initPerformanceChart() {
        const ctx = document.getElementById('performance-chart');
        if (!ctx) return;

        this.charts.performance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['لایک', 'ریتوییت', 'فالو'],
                datasets: [{
                    data: [72, 24, 4],
                    backgroundColor: [
                        '#ec4899',
                        '#10b981', 
                        '#3b82f6'
                    ],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 25,
                            usePointStyle: true,
                            color: '#e5e7eb',
                            font: { size: 13 }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(17, 24, 39, 0.9)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        cornerRadius: 12
                    }
                },
                cutout: '65%'
            }
        });
    }

    // Hashtag Popularity Chart
    initHashtagChart() {
        const ctx = document.getElementById('hashtag-chart');
        if (!ctx) return;

        this.charts.hashtags = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['#ایران', '#تهران', '#فوتبال', '#بورس', '#ارزدیجیتال'],
                datasets: [{
                    label: 'تعاملات',
                    data: [247, 189, 156, 123, 98],
                    backgroundColor: [
                        'rgba(168, 85, 247, 0.8)',
                        'rgba(59, 130, 246, 0.8)',
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(245, 158, 11, 0.8)',
                        'rgba(236, 72, 153, 0.8)'
                    ],
                    borderRadius: 12,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        ticks: { color: '#9ca3af' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#9ca3af' }
                    }
                }
            }
        });
    }

    // Account Performance Radar Chart
    initAccountPerformance() {
        const ctx = document.getElementById('account-performance');
        if (!ctx) return;

        this.charts.accounts = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['لایک', 'ریتوییت', 'سرعت', 'پایداری', 'تعامل'],
                datasets: [{
                    label: 'اکانت ۱',
                    data: [85, 70, 90, 95, 88],
                    borderColor: '#a855f7',
                    backgroundColor: 'rgba(168, 85, 247, 0.2)',
                    borderWidth: 2
                }, {
                    label: 'اکانت ۲',
                    data: [75, 85, 80, 88, 92],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.2)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        angleLines: { color: 'rgba(255,255,255,0.1)' },
                        pointLabels: { color: '#9ca3af' },
                        ticks: { color: '#9ca3af' }
                    }
                }
            }
        });
    }

    // Real-time Updates
    startRealTimeUpdates() {
        setInterval(() => {
            this.updateRealTimeData();
        }, 10000); // Update every 10 seconds
    }

    updateRealTimeData() {
        // Fetch new data from API
        fetch('/api/realtime')
            .then(response => response.json())
            .then(data => {
                if (data.success && this.charts.interactions) {
                    // Update interactions chart
                    const newData = data.data.interactions_last_hour;
                    
                    this.charts.interactions.data.labels.push(
                        new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                    );
                    this.charts.interactions.data.datasets[0].data.push(newData);
                    
                    // Keep only last 12 points
                    if (this.charts.interactions.data.labels.length > 12) {
                        this.charts.interactions.data.labels.shift();
                        this.charts.interactions.data.datasets[0].data.shift();
                    }
                    
                    this.charts.interactions.update('none');
                }
            })
            .catch(error => {
                console.error('Real-time update error:', error);
            });
    }

    // Counter Animation
    animateCounters() {
        document.querySelectorAll('.counter').forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 2000;
            const step = target / (duration / 16);
            let current = 0;

            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                counter.textContent = Math.floor(current).toLocaleString('fa-IR');
            }, 16);
        });
    }
}

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chartsManager = new ChartsManager();
    
    // Animate counters after charts load
    setTimeout(() => {
        window.chartsManager.animateCounters();
    }, 1000);
});

// Export for global use
window.ChartsManager = ChartsManager;