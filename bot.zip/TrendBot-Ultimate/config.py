import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Flask
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv('SQLALCHEMY_DATABASE_URI', 'sqlite:///trendbot.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Twitter API
    TWITTER_BEARER_TOKEN = os.getenv('TWITTER_BEARER_TOKEN')
    TW_CONSUMER_KEY = os.getenv('TW_CONSUMER_KEY')
    TW_CONSUMER_SECRET = os.getenv('TW_CONSUMER_SECRET')
    
    # Limits
    MAX_LIKES_PER_DAY = int(os.getenv('MAX_LIKES_PER_DAY', 100))
    MAX_RETWEETS_PER_DAY = int(os.getenv('MAX_RETWEETS_PER_DAY', 50))
    
    # Session
    PERMANENT_SESSION_LIFETIME = 3600  # 1 hour

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///trendbot.db')

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}