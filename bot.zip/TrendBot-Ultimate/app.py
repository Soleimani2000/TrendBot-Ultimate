import os
os.environ['HTTP_PROXY'] = 'http://85.124.247.95'
os.environ['HTTP_PROXY'] = 'http://85.124.247.95'

import os
from flask import Flask, render_template, redirect, url_for, flash, request, make_response, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, timedelta
import os
import time
import random
from threading import Thread
import pandas as pd
import io
from collections import Counter
import asyncio
from twikit import Client
app = Flask(__name__)
app.config['SECRET_KEY'] = 'ilam-trendbot-v6-secure-2025-xai'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///trendbot.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

bot_running = False
bot_thread = None

# ====================== مدل‌ها ======================
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    name = db.Column(db.String(100), default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    accounts = db.relationship('Account', backref='user', lazy=True)
    hashtags = db.relationship('Hashtag', backref='user', lazy=True)
    likes = db.relationship('Like', backref='user', lazy=True)
    retweets = db.relationship('Retweet', backref='user', lazy=True)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    full_name = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    email = db.Column(db.String(150), nullable=True)
    password = db.Column(db.String(200), nullable=False)
    api_key = db.Column(db.String(200))
    api_secret = db.Column(db.String(200))
    access_token = db.Column(db.String(200))
    access_token_secret = db.Column(db.String(200))
    bearer_token = db.Column(db.String(300))
    likes_today = db.Column(db.Integer, default=0)
    retweets_today = db.Column(db.Integer, default=0)
    last_like_date = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(20), default='unknown')
    last_checked = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Hashtag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hashtag = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.String(50), nullable=False)
    hashtag = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Retweet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.String(50), nullable=False)
    hashtag = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class BotSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    max_likes_per_day = db.Column(db.Integer, nullable=False)
    like_delay_min = db.Column(db.Integer, nullable=False)
    like_delay_max = db.Column(db.Integer, nullable=False)
    max_retweets_per_day = db.Column(db.Integer, nullable=False)
    retweet_delay_min = db.Column(db.Integer, nullable=False)
    retweet_delay_max = db.Column(db.Integer, nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# ====================== چک وضعیت واقعی با Twikit (100% کار می‌کنه) ======================
async def check_account_status(account):
    client = Client(
        'en-US',
        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        headers={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
    )
    cookie_file = f"cookies_{account.id}.json"

    try:
        if os.path.exists(cookie_file):
            client.load_cookies(cookie_file)
            user = await client.get_user_by_screen_name(account.username)
            if user:
                return 'active'
    except Exception as e:
        print(f"کوکی خراب برای @{account.username}: {e}")

    # تلاش برای لاگین با ۳ بار retry
    for i in range(3):
        try:
            await client.login(auth_info_1=account.username, password=account.password)
            client.save_cookies(cookie_file)
            return 'active'
        except Exception as e:
            error = str(e).lower()
            if 'cloudflare' in error or '403' in error or 'attention' in error:
                print(f"Cloudflare بلاک کرد — تلاش {i+1}/3")
                await asyncio.sleep(10 + i*5)
                continue
            elif any(x in error for x in ['suspended', 'locked', 'معلق']):
                return 'suspended'
            elif 'rate limit' in error or '429' in error:
                return 'limited'
            elif 'password' in error:
                return 'wrong_password'
            else:
                return 'error'
    return 'error'

# ====================== روت‌ها ======================
@app.route('/', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form['email'].strip().lower()
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password) and user.is_active:
            login_user(user)
            flash('با موفقیت وارد شدید!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('ایمیل، رمز اشتباه است یا حساب غیرفعال است!', 'error')
    return render_template('login.html')

@app.route('/toggle-theme')
@login_required
def toggle_theme():
    current_theme = request.cookies.get('theme', 'light')
    new_theme = 'dark' if current_theme == 'light' else 'light'
    resp = make_response(redirect(request.referrer or url_for('dashboard')))
    resp.set_cookie('theme', new_theme, max_age=60*60*24*365)
    return resp

@app.route('/dashboard')
@login_required
def dashboard():
    user_stats = {
        'accounts': Account.query.filter_by(user_id=current_user.id).count(),
        'hashtags': Hashtag.query.filter_by(user_id=current_user.id).count(),
        'likes_today': Like.query.filter_by(user_id=current_user.id).filter(db.func.date(Like.created_at) == date.today()).count(),
        'retweets_today': Retweet.query.filter_by(user_id=current_user.id).filter(db.func.date(Retweet.created_at) == date.today()).count(),
        'total_likes': Like.query.filter_by(user_id=current_user.id).count(),
        'total_retweets': Retweet.query.filter_by(user_id=current_user.id).count()
    }
    active_hashtags = Hashtag.query.filter_by(user_id=current_user.id, is_active=True).count()
    active_accounts = Account.query.filter_by(user_id=current_user.id).count()
    return render_template('dashboard.html', user_stats=user_stats, bot_running=bot_running,
                           active_hashtags=active_hashtags, active_accounts=active_accounts)

@app.route('/toggle-bot', methods=['POST'])
@login_required
def toggle_bot():
    global bot_running, bot_thread
    if bot_running:
        bot_running = False
        flash('بات متوقف شد', 'success')
    else:
        if not Hashtag.query.filter_by(user_id=current_user.id, is_active=True).first():
            flash('حداقل یک هشتگ فعال اضافه کنید!', 'error')
            return redirect(url_for('dashboard'))
        if not Account.query.filter_by(user_id=current_user.id).first():
            flash('حداقل یک اکانت اضافه کنید!', 'error')
            return redirect(url_for('dashboard'))
        bot_running = True
        bot_thread = Thread(target=run_bot, daemon=True)
        bot_thread.start()
        flash('بات با موفقیت شروع شد!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/accounts')
@login_required
def accounts():
    if current_user.is_admin:
        accounts = Account.query.all()
    else:
        accounts = Account.query.filter_by(user_id=current_user.id).all()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    for acc in accounts:
        if not acc.last_checked or (datetime.utcnow() - acc.last_checked).total_seconds() > 300:
            status = loop.run_until_complete(check_account_status(acc))
            acc.status = status
            acc.last_checked = datetime.utcnow()

    with app.app_context():
        db.session.bulk_update_mappings(Account, [
            {'id': acc.id, 'status': acc.status, 'last_checked': acc.last_checked} for acc in accounts
        ])
        db.session.commit()

    loop.close()
    return render_template('accounts.html', accounts=accounts)

@app.route('/hashtags')
@login_required
def hashtags():
    user_hashtags = Hashtag.query.filter_by(user_id=current_user.id).order_by(Hashtag.created_at.desc()).all()
    return render_template('hashtags.html', hashtags=user_hashtags)

@app.route('/hashtags/add', methods=['POST'])
@login_required
def hashtag_add():
    hashtag_text = request.form['hashtag'].strip().lstrip('#')
    if not hashtag_text:
        flash('هشتگ نمی‌تواند خالی باشد!', 'error')
    else:
        full_hashtag = f'#{hashtag_text}'
        if not Hashtag.query.filter_by(user_id=current_user.id, hashtag=full_hashtag).first():
            db.session.add(Hashtag(hashtag=full_hashtag, user_id=current_user.id, is_active=True))
            db.session.commit()
            flash(f'هشتگ {full_hashtag} اضافه شد!', 'success')
        else:
            flash('این هشتگ قبلاً اضافه شده!', 'error')
    return redirect(url_for('hashtags'))

@app.route('/hashtags/toggle/<int:hashtag_id>', methods=['POST'])
@login_required
def hashtag_toggle(hashtag_id):
    h = Hashtag.query.get_or_404(hashtag_id)
    if h.user_id == current_user.id:
        h.is_active = not h.is_active
        db.session.commit()
        flash(f'هشتگ {h.hashtag} → {"فعال" if h.is_active else "غیرفعال"} شد', 'success')
    return redirect(url_for('hashtags'))

@app.route('/hashtags/delete/<int:hashtag_id>', methods=['POST'])
@login_required
def hashtag_delete(hashtag_id):
    h = Hashtag.query.get_or_404(hashtag_id)
    if h.user_id == current_user.id:
        db.session.delete(h)
        db.session.commit()
        flash(f'هشتگ {h.hashtag} حذف شد.', 'success')
    return redirect(url_for('hashtags'))

@app.route('/logs')
@login_required
def logs():
    if current_user.is_admin:
        users = User.query.all()
        users_summary = []
        for u in users:
            accounts = Account.query.filter_by(user_id=u.id).all()
            hashtags = Hashtag.query.filter_by(user_id=u.id).all()
            likes_today = Like.query.filter_by(user_id=u.id).filter(db.func.date(Like.created_at) == date.today()).count()
            retweets_today = Retweet.query.filter_by(user_id=u.id).filter(db.func.date(Retweet.created_at) == date.today()).count()
            total_likes = Like.query.filter_by(user_id=u.id).count()
            total_retweets = Retweet.query.filter_by(user_id=u.id).count()
            last_like = db.session.query(db.func.max(Like.created_at)).filter_by(user_id=u.id).scalar()
            last_retweet = db.session.query(db.func.max(Retweet.created_at)).filter_by(user_id=u.id).scalar()
            last_activity = max(filter(None, [last_like, last_retweet])) if any([last_like, last_retweet]) else None

            users_summary.append({
                'id': u.id,
                'name': u.name,
                'email': u.email,
                'accounts_count': len(accounts),
                'accounts_list': [a.username for a in accounts],
                'hashtags_count': len(hashtags),
                'hashtags_list': [h.hashtag for h in hashtags],
                'likes_today': likes_today,
                'total_likes': total_likes,
                'retweets_today': retweets_today,
                'total_retweets': total_retweets,
                'last_activity': last_activity,
                'last_activity_date': last_activity.strftime('%Y-%m-%d') if last_activity else '',
            })

        return render_template('logs.html', users_summary=users_summary)
    else:
        likes = Like.query.filter_by(user_id=current_user.id).order_by(Like.created_at.desc()).all()
        retweets = Retweet.query.filter_by(user_id=current_user.id).order_by(Retweet.created_at.desc()).all()
        logs = []
        accounts_dict = {a.id: a.username for a in Account.query.filter_by(user_id=current_user.id).all()}
        for l in likes:
            logs.append({
                'time': l.created_at.strftime('%H:%M:%S'),
                'date': l.created_at.strftime('%Y-%m-%d'),
                'account': accounts_dict.get(l.user_id, 'نامشخص'),
                'type': 'like',
                'hashtag': l.hashtag,
                'tweet_id': l.tweet_id
            })
        for r in retweets:
            logs.append({
                'time': r.created_at.strftime('%H:%M:%S'),
                'date': r.created_at.strftime('%Y-%m-%d'),
                'account': accounts_dict.get(r.user_id, 'نامشخص'),
                'type': 'retweet',
                'hashtag': r.hashtag,
                'tweet_id': r.tweet_id
            })
        logs.sort(key=lambda x: f"{x['date']} {x['time']}", reverse=True)
        total_ops = len(logs)
        success_rate = round((total_ops / total_ops * 100), 1) if total_ops > 0 else 0
        return render_template('logs.html',
            logs=logs[:500],
            total_ops=total_ops,
            successful_ops=total_ops,
            failed_ops=0,
            success_rate=success_rate
        )

@app.route('/clear-logs', methods=['POST'])
@login_required
def clear_logs():
    Like.query.filter_by(user_id=current_user.id).delete()
    Retweet.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    flash('تمام لاگ‌ها پاک شد!', 'success')
    return redirect(url_for('logs'))

@app.route('/download-logs')
@login_required
def download_logs():
    likes = Like.query.filter_by(user_id=current_user.id).all()
    retweets = Retweet.query.filter_by(user_id=current_user.id).all()
    output = io.StringIO()
    output.write("زمان,اکانت,عملیات,هشتگ,وضعیت,Tweet ID\n")
    for l in likes:
        acc = Account.query.get(l.user_id)
        output.write(f"{l.created_at},@{acc.username if acc else 'نامشخص'},لایک,{l.hashtag},موفق,{l.tweet_id}\n")
    for r in retweets:
        acc = Account.query.get(r.user_id)
        output.write(f"{r.created_at},@{acc.username if acc else 'نامشخص'},ریتوییت,{r.hashtag},موفق,{r.tweet_id}\n")
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'لاگ_بات_{date.today()}.csv'
    )

@app.route('/download-report')
@login_required
def download_report():
    return download_logs()

@app.route('/analytics')
@login_required
def analytics():
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))

    total_likes = Like.query.count()
    total_retweets = Retweet.query.count()
    total_interactions = total_likes + total_retweets
    today_interactions = Like.query.filter(db.func.date(Like.created_at) == date.today()).count() + \
                         Retweet.query.filter(db.func.date(Retweet.created_at) == date.today()).count()
    active_accounts = Account.query.filter_by(is_active=True).count()
    online_accounts = active_accounts
    total_ops = total_interactions
    success_rate = round((total_ops / total_ops * 100) if total_ops > 0 else 0, 1)

    first_like = db.session.query(db.func.min(Like.created_at)).scalar()
    first_retweet = db.session.query(db.func.min(Retweet.created_at)).scalar()
    first_activity_dates = [d for d in [first_like, first_retweet] if d is not None]
    days_active = max(1, (date.today() - min(first_activity_dates).date()).days) if first_activity_dates else 1
    avg_per_day = round(total_interactions / days_active, 1)

    week_start = date.today() - timedelta(days=6)
    interactions_this_week = Like.query.filter(Like.created_at >= week_start).count() + Retweet.query.filter(Retweet.created_at >= week_start).count()
    previous_week_start = week_start - timedelta(days=7)
    previous_week_end = week_start
    interactions_previous_week = Like.query.filter(Like.created_at >= previous_week_start, Like.created_at < previous_week_end).count() + \
                                 Retweet.query.filter(Retweet.created_at >= previous_week_start, Retweet.created_at < previous_week_end).count()
    weekly_growth = round(((interactions_this_week - interactions_previous_week) / interactions_previous_week * 100) 
                          if interactions_previous_week > 0 else 0, 1)

    hours = [f"{h:02d}:00" for h in range(24)]
    hourly_data = []
    for h in range(24):
        start = datetime.combine(date.today(), datetime.min.time()) + timedelta(hours=h)
        end = start + timedelta(hours=1)
        count = Like.query.filter(Like.created_at >= start, Like.created_at < end).count() + \
                Retweet.query.filter(Retweet.created_at >= start, Retweet.created_at < end).count()
        hourly_data.append(count)

    account_performance = []
    for acc in Account.query.all():
        likes = Like.query.filter_by(user_id=acc.user_id).count()
        retweets = Retweet.query.filter_by(user_id=acc.user_id).count()
        account_performance.append({'username': acc.username, 'likes': likes, 'retweets': retweets, 'total': likes + retweets})

    hashtags = [l.hashtag for l in Like.query.all()] + [r.hashtag for r in Retweet.query.all()]
    top_hashtags = [{'hashtag': h, 'count': c} for h, c in Counter(hashtags).most_common(10)]

    recent_activity = []
    recent_likes = Like.query.order_by(Like.created_at.desc()).limit(10).all()
    recent_retweets = Retweet.query.order_by(Retweet.created_at.desc()).limit(10).all()
    for l in recent_likes:
        acc = Account.query.get(l.user_id)
        time_ago = 'همین الان' if (datetime.utcnow() - l.created_at).seconds < 60 else f'{int((datetime.utcnow() - l.created_at).seconds / 60)} دقیقه پیش'
        recent_activity.append({'account': acc.username if acc else 'نامشخص', 'type': 'like', 'hashtag': l.hashtag, 'time_ago': time_ago})
    for r in recent_retweets:
        acc = Account.query.get(r.user_id)
        time_ago = 'همین الان' if (datetime.utcnow() - r.created_at).seconds < 60 else f'{int((datetime.utcnow() - r.created_at).seconds / 60)} دقیقه پیش'
        recent_activity.append({'account': acc.username if acc else 'نامشخص', 'type': 'retweet', 'hashtag': r.hashtag, 'time_ago': time_ago})
    recent_activity.sort(key=lambda x: x['time_ago'], reverse=True)
    recent_activity = recent_activity[:10]

    return render_template('analytics.html',
        total_interactions=total_interactions, today_interactions=today_interactions,
        total_likes=total_likes, total_retweets=total_retweets,
        active_accounts=active_accounts, online_accounts=online_accounts,
        success_rate=success_rate, avg_per_day=avg_per_day, weekly_growth=weekly_growth,
        hourly_labels=hours, hourly_data=hourly_data,
        account_performance=account_performance, top_hashtags=top_hashtags,
        recent_activity=recent_activity
    )

@app.route('/users')
@login_required
def users():
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    users_list = User.query.all()
    return render_template('users.html', users_list=users_list)

@app.route('/users/add', methods=['GET', 'POST'])
@login_required
def user_add():
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password']
        name = request.form.get('name', '').strip()
        is_admin = 'is_admin' in request.form
        if User.query.filter_by(email=email).first():
            flash('این ایمیل قبلاً ثبت شده است!', 'error')
        elif len(password) < 6:
            flash('رمز عبور باید حداقل ۶ کاراکتر باشد!', 'error')
        else:
            new_user = User(email=email, name=name, is_admin=is_admin)
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()
            flash('کاربر با موفقیت اضافه شد!', 'success')
            return redirect(url_for('users'))
    return render_template('user_add.html')

@app.route('/users/delete/<int:user_id>', methods=['POST'])
@login_required
def user_delete(user_id):
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    user_to_delete = User.query.get_or_404(user_id)
    if user_to_delete.id == current_user.id:
        flash('نمی‌توانید حساب خود را حذف کنید!', 'error')
        return redirect(url_for('users'))
    db.session.delete(user_to_delete)
    db.session.commit()
    flash('کاربر با موفقیت حذف شد!', 'success')
    return redirect(url_for('users'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        if 'name' in request.form:
            current_user.name = request.form['name'].strip()
        if 'email' in request.form:
            new_email = request.form['email'].strip().lower()
            if new_email != current_user.email and User.query.filter_by(email=new_email).first():
                flash('ایمیل تکراری!', 'error')
            else:
                current_user.email = new_email
        if 'password' in request.form and len(request.form['password']) >= 6:
            current_user.set_password(request.form['password'])
        db.session.commit()
        flash('پروفایل بروز شد!', 'success')
    return render_template('profile.html')

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    
    bot_settings = BotSettings.query.first()
    if request.method == 'POST':
        if not bot_settings:
            bot_settings = BotSettings()
            db.session.add(bot_settings)
        
        bot_settings.max_likes_per_day = int(request.form['max_likes_per_day'])
        bot_settings.like_delay_min = int(request.form['like_delay_min'])
        bot_settings.like_delay_max = int(request.form['like_delay_max'])
        bot_settings.max_retweets_per_day = int(request.form['max_retweets_per_day'])
        bot_settings.retweet_delay_min = int(request.form['retweet_delay_min'])
        bot_settings.retweet_delay_max = int(request.form['retweet_delay_max'])
        db.session.commit()
        flash('تنظیمات مرکزی با موفقیت ذخیره شد!', 'success')
        return redirect(url_for('settings'))
    
    if not bot_settings:
        flash('لطفاً تنظیمات مرکزی را وارد و ذخیره کنید!', 'error')
    
    return render_template('settings.html', settings=bot_settings)

@app.route('/account/add', methods=['GET', 'POST'])
@login_required
def account_add():
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lstrip('@')
        password = request.form.get('password', '').strip()
        email = request.form.get('email', '').strip() or None

        if not username or not password:
            flash('نام کاربری و رمز عبور اجباری هستند!', 'error')
            return redirect('/account/add')

        if Account.query.filter_by(username=username, user_id=current_user.id).first():
            flash('این اکانت قبلاً اضافه شده!', 'error')
            return redirect('/account/add')

        new_account = Account(
            username=username,
            password=password,
            email=email,
            user_id=current_user.id,
            is_active=True,
            status='checking'
        )
        db.session.add(new_account)
        db.session.commit()

        loop = asyncio.new_event_loop()
        status = loop.run_until_complete(check_account_status(new_account))
        new_account.status = status
        db.session.commit()
        loop.close()

        flash(f'اکانت @{username} اضافه شد — وضعیت: {status}', 'success')
        return redirect('/accounts')

    return render_template('account_add.html')

@app.route('/account/delete/<int:account_id>', methods=['POST'])
@login_required
def account_delete(account_id):
    account = Account.query.get_or_404(account_id)
    if account.user_id != current_user.id:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect('/accounts')
    cookie_file = f"cookies_{account.id}.json"
    if os.path.exists(cookie_file):
        os.remove(cookie_file)
    db.session.delete(account)
    db.session.commit()
    flash(f'اکانت @{account.username} حذف شد!', 'success')
    return redirect('/accounts')

@app.route('/accounts/bulk-add', methods=['GET', 'POST'])
@login_required
def bulk_add_accounts():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('فایلی انتخاب نشده!', 'error')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('فایلی انتخاب نشده!', 'error')
            return redirect(request.url)
        if file and (file.filename.endswith('.csv') or file.filename.endswith('.xlsx')):
            try:
                if file.filename.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    df = pd.read_excel(file)
                
                added = skipped = 0
                for _, row in df.iterrows():
                    username = str(row.get('username', '')).strip().lstrip('@')
                    password = str(row.get('password', '')).strip()
                    email = str(row.get('email', '')).strip() or None

                    if not username or not password:
                        skipped += 1
                        continue
                    if Account.query.filter_by(username=username, user_id=current_user.id).first():
                        skipped += 1
                        continue
                    new_acc = Account(
                        username=username,
                        password=password,
                        email=email,
                        user_id=current_user.id,
                        is_active=True,
                        status='checking'
                    )
                    db.session.add(new_acc)
                    added += 1
                db.session.commit()
                flash(f'{added} اکانت اضافه شد! ({skipped} رد شد)', 'success')
                return redirect('/accounts')
            except Exception as e:
                flash(f'خطا در فایل: {str(e)}', 'error')
        else:
            flash('فقط CSV و Excel مجاز است!', 'error')
    return render_template('bulk_add.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('خارج شدید', 'success')
    resp = make_response(redirect(url_for('login')))
    resp.delete_cookie('theme')
    return resp

@app.route('/users/toggle-admin/<int:user_id>', methods=['POST'])
@login_required
def toggle_admin(user_id):
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('نمی‌توانید دسترسی خودتان را تغییر دهید!', 'error')
        return redirect(url_for('users'))
    user.is_admin = not user.is_admin
    db.session.commit()
    flash(f'سطح دسترسی کاربر {user.email} تغییر کرد به {"ادمین" if user.is_admin else "کاربر عادی"}', 'success')
    return redirect(url_for('users'))

@app.route('/users/toggle-active/<int:user_id>', methods=['POST'])
@login_required
def toggle_active(user_id):
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('نمی‌توانید حساب خودتان را غیرفعال کنید!', 'error')
        return redirect(url_for('users'))
    user.is_active = not user.is_active
    db.session.commit()
    flash(f'کاربر {user.email} اکنون {"فعال" if user.is_active else "غیرفعال"} شد', 'success')
    return redirect(url_for('users'))

@app.route('/user-detail/<int:user_id>')
@login_required
def user_detail(user_id):
    if not current_user.is_admin:
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    u = User.query.get_or_404(user_id)
    accounts = Account.query.filter_by(user_id=u.id).all()
    account_stats = []
    for acc in accounts:
        likes = Like.query.filter_by(user_id=u.id).count()
        retweets = Retweet.query.filter_by(user_id=u.id).count()
        account_stats.append({'username': acc.username, 'likes': likes, 'retweets': retweets, 'total': likes + retweets})
    hashtags = Hashtag.query.filter_by(user_id=u.id).all()
    hashtag_stats = []
    for h in hashtags:
        likes = Like.query.filter_by(user_id=u.id, hashtag=h.hashtag).count()
        retweets = Retweet.query.filter_by(user_id=u.id, hashtag=h.hashtag).count()
        hashtag_stats.append({'hashtag': h.hashtag, 'likes': likes, 'retweets': retweets, 'total': likes + retweets})
    logs = []
    likes = Like.query.filter_by(user_id=u.id).order_by(Like.created_at.desc()).all()
    retweets = Retweet.query.filter_by(user_id=u.id).order_by(Retweet.created_at.desc()).all()
    accounts_dict = {a.id: a.username for a in accounts}
    for l in likes:
        acc = Account.query.get(l.user_id)
        logs.append({'time': l.created_at.strftime('%Y/%m/%d - %H:%M:%S'), 'account': acc.username if acc else 'نامشخص', 'type': 'like', 'hashtag': l.hashtag, 'tweet_id': l.tweet_id})
    for r in retweets:
        acc = Account.query.get(r.user_id)
        logs.append({'time': r.created_at.strftime('%Y/%m/%d - %H:%M:%S'), 'account': acc.username if acc else 'نامشخص', 'type': 'retweet', 'hashtag': r.hashtag, 'tweet_id': r.tweet_id})
    logs.sort(key=lambda x: x['time'], reverse=True)
    total_likes = Like.query.filter_by(user_id=u.id).count()
    total_retweets = Retweet.query.filter_by(user_id=u.id).count()
    return render_template('user_detail.html', user=u, accounts=accounts, hashtags=hashtags, account_stats=account_stats, hashtag_stats=hashtag_stats, logs=logs[:500], total_likes=total_likes, total_retweets=total_retweets)

# ====================== ربات اصلی — بدون context error و بدون Cloudflare ======================
def run_bot():
    global bot_running
    print("ربات Twikit شروع شد — فقط یوزرنیم + پسورد")

    async def worker():
        while bot_running:
            try:
                with app.app_context():
                    accounts = Account.query.filter_by(is_active=True).all()
                    hashtags = [h.hashtag.lstrip('#') for h in Hashtag.query.filter_by(is_active=True).all()]

                if not accounts or not hashtags:
                    await asyncio.sleep(30)
                    continue

                for acc in accounts:
                    client = Client(
                        'en-US',
                        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
                        headers={
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.9',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'DNT': '1',
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                        }
                    )
                    cookie_file = f"cookies_{acc.id}.json"

                    try:
                        if os.path.exists(cookie_file):
                            client.load_cookies(cookie_file)
                        else:
                            for attempt in range(3):
                                try:
                                    await client.login(auth_info_1=acc.username, password=acc.password)
                                    client.save_cookies(cookie_file)
                                    break
                                except Exception as e:
                                    if 'cloudflare' in str(e).lower():
                                        print(f"Cloudflare بلاک کرد — تلاش {attempt+1}/3")
                                        await asyncio.sleep(10 + attempt*5)
                                    else:
                                        raise

                        for tag in hashtags:
                            try:
                                tweets = await client.search_tweet(f"#{tag}", 'Latest', count=50)
                                for tweet in tweets:
                                    try:
                                        await tweet.favorite()
                                        with app.app_context():
                                            acc.likes_today += 1
                                            db.session.commit()
                                        print(f"فیو: @{acc.username} → {tweet.id}")
                                    except: pass

                                    try:
                                        await tweet.retweet()
                                        with app.app_context():
                                            acc.retweets_today += 1
                                            db.session.commit()
                                        print(f"ریت: @{acc.username} → {tweet.id}")
                                    except: pass

                                    await asyncio.sleep(random.uniform(4, 9))
                            except Exception as e:
                                print(f"خطا در سرچ #{tag}: {e}")
                    except Exception as e:
                        print(f"خطا در اکانت @{acc.username}: {e}")

                await asyncio.sleep(60)
            except Exception as e:
                print(f"خطای کلی ربات: {e}")
                await asyncio.sleep(30)

    if bot_running:
        asyncio.run(worker())

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(email='admin@ilamtrendbot.ir').first():
            admin = User(email='admin@ilamtrendbot.ir', name='ادمین اصلی', is_admin=True)
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print('ادمین ساخته شد: admin@ilamtrendbot.ir / admin123')
    
    print("TrendBot Ultimate v21.0 آماده است!")
    app.run(debug=True, host='0.0.0.0', port=8080)