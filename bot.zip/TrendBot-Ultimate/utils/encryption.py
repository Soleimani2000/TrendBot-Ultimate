from cryptography.fernet import Fernet
import base64
import os
from typing import Optional

class EncryptionManager:
    _instance = None
    _key = None
    _cipher = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(EncryptionManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._cipher is None:
            self._load_key()
            self._initialize_cipher()
    
    def _load_key(self):
        """Load or generate encryption key"""
        key_file = 'encryption.key'
        
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                self._key = f.read()
        else:
            # Generate new key
            self._key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(self._key)
    
    def _initialize_cipher(self):
        """Initialize Fernet cipher"""
        self._cipher = Fernet(self._key)
    
    def encrypt(self, data: str) -> str:
        """Encrypt data"""
        try:
            encrypted = self._cipher.encrypt(data.encode())
            # Return base64 encoded for database storage
            return base64.urlsafe_b64encode(encrypted).decode()
        except Exception as e:
            raise Exception(f"Encryption failed: {e}")
    
    def decrypt(self, encrypted_data: str) -> Optional[str]:
        """Decrypt data"""
        try:
            # Decode base64
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted = self._cipher.decrypt(encrypted_bytes)
            return decrypted.decode()
        except Exception as e:
            print(f"Decryption failed: {e}")
            return None

# Global instance
encrypt_manager = EncryptionManager()

def encrypt(data: str) -> str:
    """Global encrypt function"""
    return encrypt_manager.encrypt(data)

def decrypt(encrypted_data: str) -> Optional[str]:
    """Global decrypt function"""
    return encrypt_manager.decrypt(encrypted_data)