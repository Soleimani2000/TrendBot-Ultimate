"""
TrendBot Ultimate - Log Management
"""

import os
import json
import logging
from datetime import datetime
from pathlib import Path

class LogManager:
    def __init__(self):
        self.log_dir = Path("logs")
        self.log_dir.mkdir(exist_ok=True)
        self.setup_logging()
    
    def setup_logging(self):
        """Setup structured logging"""
        # App logger
        app_handler = logging.FileHandler('logs/app.log', encoding='utf-8')
        app_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        ))
        
        # Bot logger
        bot_handler = logging.FileHandler('logs/bot/bot.log', encoding='utf-8')
        bot_handler.setLevel(logging.INFO)
        
        # Worker logger
        worker_handler = logging.FileHandler('logs/worker/worker.log', encoding='utf-8')
        worker_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(
            '🚀 %(asctime)s | %(levelname)s | %(message)s'
        ))
    
    def log_bot_action(self, action_data):
        """Log bot action to JSON file"""
        log_file = self.log_dir / "bot" / f"bot_actions_{datetime.now().strftime('%Y%m%d')}.json"
        log_file.parent.mkdir(exist_ok=True)
        
        try:
            if log_file.exists():
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
            else:
                logs = []
            
            logs.insert(0, action_data)
            # Keep only last 10,000 entries
            if len(logs) > 10000:
                logs = logs[:10000]
            
            with open(log_file, 'w', encoding='utf-8') as f:
                json.dump(logs, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logging.error(f"Failed to write bot action log: {e}")
    
    def rotate_logs(self):
        """Rotate log files daily"""
        for log_file in self.log_dir.rglob("*.log"):
            if log_file.name != "app.log":
                # Keep logs for 7 days
                if datetime.now().timestamp() - log_file.stat().st_mtime > 7 * 24 * 3600:
                    log_file.unlink()
    
    def get_stats(self):
        """Get log statistics"""
        stats = {
            'total_files': len(list(self.log_dir.rglob('*'))),
            'app_size': sum(f.stat().st_size for f in self.log_dir.glob('app/*.log')),
            'bot_size': sum(f.stat().st_size for f in self.log_dir.glob('bot/*.log')),
            'worker_size': sum(f.stat().st_size for f in self.log_dir.glob('worker/*.log')),
            'recent_actions': []
        }
        
        # Get recent bot actions
        actions_file = self.log_dir / "bot" / f"bot_actions_{datetime.now().strftime('%Y%m%d')}.json"
        if actions_file.exists():
            with open(actions_file, 'r', encoding='utf-8') as f:
                actions = json.load(f)
                stats['recent_actions'] = actions[:10]
        
        return stats

# Global log manager
log_manager = LogManager()