#!/bin/bash
set -e

echo "🚀 Starting TrendBot Ultimate Docker Container..."

# Wait for PostgreSQL (if using)
if [ "$DATABASE_URL" ] && [ "$WAIT_FOR_DB" = "true" ]; then
    echo "⏳ Waiting for PostgreSQL..."
    until nc -z -v -w30 "${DB_HOST:-postgres}" "${DB_PORT:-5432}"; do
        echo "⏳ PostgreSQL is unavailable - sleeping..."
        sleep 5
    done
    echo "✅ PostgreSQL is ready!"
fi

# Create necessary directories
mkdir -p /app/logs /app/static/uploads /app/backups
chmod 755 /app/logs /app/static/uploads /app/backups

# Collect static files
echo "📦 Collecting static files..."
python manage.py collectstatic --noinput || echo "Static files collection skipped"

# Run database migrations
echo "🔄 Running database migrations..."
python database.py || echo "Database initialization completed or skipped"

# Set file permissions
chown -R 1000:1000 /app/logs /app/static/uploads /app/backups

# Start application
echo "✅ TrendBot Ultimate is starting..."
echo "🌐 Application will be available at: http://localhost:8080"
echo "📧 Default login: admin@trendbot.ir / admin123"

# Execute command
exec "$@"