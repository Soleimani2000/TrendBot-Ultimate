from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    username = db.Column(db.String(50), unique=True)
    password_hash = db.Column(db.String(128), nullable=False)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class TwitterAccount(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    access_token = db.Column(db.Text, nullable=False)
    access_token_secret = db.Column(db.Text, nullable=False)
    max_likes_per_day = db.Column(db.Integer, default=100)
    max_retweets_per_day = db.Column(db.Integer, default=50)
    likes_today = db.Column(db.Integer, default=0)
    retweets_today = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    last_active = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    processed_tweets = db.relationship('ProcessedTweet', backref='account', lazy=True)

class Hashtag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tag = db.Column(db.String(50), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ProcessedTweet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.String(20), nullable=False, index=True)
    account_id = db.Column(db.Integer, db.ForeignKey('twitter_account.id'), nullable=False)
    hashtag = db.Column(db.String(50))
    action = db.Column(db.String(10), nullable=False)  # 'like', 'retweet'
    success = db.Column(db.Boolean, default=True)
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.UniqueConstraint('tweet_id', 'account_id', 'action', name='unique_tweet_action'),
    )# Models 
