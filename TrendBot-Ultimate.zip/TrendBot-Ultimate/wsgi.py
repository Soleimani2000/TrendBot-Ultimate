#!/usr/bin/env python3
"""
WSGI entry point for Gunicorn
"""

import os
import sys

# Add project root to Python path
sys.path.insert(0, os.path.dirname(__file__))

from app import app, db

# Initialize database if needed
with app.app_context():
    # Ensure tables exist
    db.create_all()

if __name__ == "__main__":
    app.run()