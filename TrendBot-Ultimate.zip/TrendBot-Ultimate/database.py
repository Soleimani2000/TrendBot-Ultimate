from app import app, db, User
import os

def create_database():
    """Create database and tables"""
    with app.app_context():
        db.create_all()
        
        # Create default admin user
        admin_email = 'admin@trendbot.ir'
        admin_password = 'admin123'
        
        if not User.query.filter_by(email=admin_email).first():
            admin = User(
                email=admin_email,
                username='admin'
            )
            admin.set_password(admin_password)
            db.session.add(admin)
            db.session.commit()
            
            print("✅ Database created successfully!")
            print("=" * 50)
            print("👤 ADMIN USER CREATED:")
            print(f"   📧 Email: {admin_email}")
            print(f"   🔑 Password: {admin_password}")
            print(f"   🌐 Login: http://localhost:8080")
            print("=" * 50)
        else:
            print("✅ Database already exists with admin user")

def reset_database():
    """Reset database (WARNING: Deletes all data)"""
    with app.app_context():
        db.drop_all()
        db.create_all()
        print("🔄 Database reset completed")

if __name__ == "__main__":
    action = input("Choose action:\n1. Create database\n2. Reset database\nEnter (1 or 2): ")
    
    if action == "1":
        create_database()
    elif action == "2":
        confirm = input("⚠️  This will delete ALL data! Continue? (y/N): ")
        if confirm.lower() == 'y':
            reset_database()
            create_database()
        else:
            print("❌ Reset cancelled")
    else:
        print("❌ Invalid option")