from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import os
from models import db, User, TwitterAccount, Hashtag, ProcessedTweet

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'trendbot-secret-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///trendbot.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            flash('✅ با موفقیت وارد شدید!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('❌ ایمیل یا رمز عبور اشتباه است!', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('👋 با موفقیت خارج شدید!', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    today = date.today()
    
    likes = db.session.query(ProcessedTweet).filter(
        ProcessedTweet.action == 'like',
        db.func.date(ProcessedTweet.created_at) == today
    ).count()
    
    retweets = db.session.query(ProcessedTweet).filter(
        ProcessedTweet.action == 'retweet',
        db.func.date(ProcessedTweet.created_at) == today
    ).count()
    
    active_accounts = TwitterAccount.query.filter_by(is_active=True).count()
    hashtags_count = Hashtag.query.count()
    
    stats = {
        'likes': likes,
        'retweets': retweets,
        'total': likes + retweets,
        'accounts': active_accounts,
        'hashtags': hashtags_count
    }
    
    return render_template('dashboard.html', stats=stats)

@app.route('/api/stats')
@login_required
def api_stats():
    today = date.today()
    
    likes = db.session.query(ProcessedTweet).filter(
        ProcessedTweet.action == 'like',
        db.func.date(ProcessedTweet.created_at) == today
    ).count()
    
    retweets = db.session.query(ProcessedTweet).filter(
        ProcessedTweet.action == 'retweet',
        db.func.date(ProcessedTweet.created_at) == today
    ).count()
    
    return jsonify({
        'likes': likes,
        'retweets': retweets,
        'total': likes + retweets
    })

@app.route('/accounts')
@login_required
def accounts():
    accounts = TwitterAccount.query.all()
    return render_template('accounts.html', accounts=accounts)

@app.route('/accounts/add', methods=['GET', 'POST'])
@login_required
def account_add():
    if request.method == 'POST':
        account = TwitterAccount(
            name=request.form['name'],
            access_token=request.form['access_token'],
            access_token_secret=request.form['access_token_secret'],
            max_likes_per_day=int(request.form.get('max_likes_per_day', 100)),
            max_retweets_per_day=int(request.form.get('max_retweets_per_day', 50))
        )
        db.session.add(account)
        db.session.commit()
        flash('✅ اکانت با موفقیت اضافه شد!', 'success')
        return redirect(url_for('accounts'))
    
    return render_template('account_add.html')

@app.route('/hashtags')
@login_required
def hashtags():
    tags = Hashtag.query.all()
    return render_template('hashtags.html', hashtags=tags)

@app.route('/hashtags/add', methods=['POST'])
@login_required
def hashtag_add():
    tag = request.form['tag'].strip().lstrip('#')
    if tag and not Hashtag.query.filter_by(tag=tag).first():
        hashtag = Hashtag(tag=tag)
        db.session.add(hashtag)
        db.session.commit()
        flash(f'✅ هشتگ #{tag} اضافه شد!', 'success')
    else:
        flash('❌ این هشتگ از قبل وجود دارد!', 'error')
    
    return redirect(url_for('hashtags'))

def init_db():
    with app.app_context():
        db.create_all()
        
        # ایجاد ادمین پیش‌فرض
        if not User.query.filter_by(email='admin@trendbot.ir').first():
            admin = User(
                email='admin@trendbot.ir',
                username='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("✅ ادمین ایجاد شد:")
            print("   ایمیل: admin@trendbot.ir")
            print("   رمز: admin123")

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=8080)from flask import Flask 
