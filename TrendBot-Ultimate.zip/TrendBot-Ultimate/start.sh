#!/bin/bash
# TrendBot Ultimate - One-Click Startup Script
# نسخه: 2.0.0 | تاریخ: 2024
# ============================================

set -e

# رنگ‌ها برای خروجی زیبا
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# متغیرهای پروژه
PROJECT_NAME="TrendBot-Ultimate"
PROJECT_DIR="$(pwd)"
LOG_FILE="$PROJECT_DIR/logs/startup.log"
BACKUP_DIR="$PROJECT_DIR/backups"
STATIC_DIR="$PROJECT_DIR/static/uploads"

# تابع چاپ لوگو
print_logo() {
    clear
    echo -e "${PURPLE}"
    cat << "EOF"
    ╔══════════════════════════════════════════════════════╗
    ║                                                      ║
    ║    🚀  TREND BOT ULTIMATE v2.0  🚀                   ║
    ║    📊  پنل مدیریت بات توییتر پیشرفته                 ║
    ║                                                      ║
    ╚══════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
}

# تابع چاپ وضعیت
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

# تابع چاپ هشدار
print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# تابع چاپ خطا
print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# تابع لاگ
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# بررسی سیستم عامل
check_os() {
    print_status "بررسی سیستم عامل..."
    if [[ "$OSTYPE" == "linux-gnu"* ]] || [[ "$OSTYPE" == "darwin"* ]]; then
        log "سیستم عامل پشتیبانی شده: $OSTYPE"
        print_status "✅ سیستم عامل مناسب"
    else
        print_error "سیستم عامل پشتیبانی نمی‌شود!"
        exit 1
    fi
}

# ایجاد پوشه‌های مورد نیاز
create_directories() {
    print_status "ایجاد پوشه‌های مورد نیاز..."
    
    mkdir -p logs static/uploads backups database
    mkdir -p logs/{app,bot,worker}
    mkdir -p backups/{daily,weekly,monthly}
    mkdir -p static/{css,js,images,uploads}
    
    # تنظیم مجوزها
    chmod 755 logs static/uploads backups
    chmod 777 logs/*
    
    log "پوشه‌ها ایجاد شد"
    print_status "✅ پوشه‌ها آماده"
}

# نصب وابستگی‌های سیستمی
install_system_deps() {
    print_status "نصب وابستگی‌های سیستمی..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if command -v apt &> /dev/null; then
            sudo apt update
            sudo apt install -y python3 python3-pip python3-venv git curl wget
        elif command -v yum &> /dev/null; then
            sudo yum install -y python3 python3-pip git curl wget
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        if command -v brew &> /dev/null; then
            brew install python git
        fi
    fi
    
    print_status "✅ وابستگی‌های سیستمی نصب شد"
}

# نصب Python dependencies
install_python_deps() {
    print_status "نصب پکیج‌های Python..."
    
    # ایجاد virtual environment
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_status "محیط مجازی ایجاد شد"
    fi
    
    # فعال‌سازی
    source venv/bin/activate
    
    # به‌روزرسانی pip
    pip install --upgrade pip
    
    # نصب وابستگی‌ها
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
        print_status "✅ پکیج‌های Python نصب شد"
    else
        print_error "فایل requirements.txt یافت نشد!"
        exit 1
    fi
}

# راه‌اندازی دیتابیس
setup_database() {
    print_status "راه‌اندازی دیتابیس..."
    
    # اجرای اسکریپت دیتابیس
    if command -v python3 &> /dev/null; then
        python3 database.py
    else
        python database.py
    fi
    
    # تست اتصال
    if python3 -c "from database import db; print('✅ دیتابیس آماده')" 2>/dev/null; then
        print_status "✅ دیتابیس راه‌اندازی شد"
    else
        print_warning "⚠️  هشدار در اتصال دیتابیس"
    fi
}

# تست بات توییتر
test_twitter_bot() {
    print_status "تست اتصال بات توییتر..."
    
    # ایجاد فایل تست
    cat > test_bot.py << 'EOF'
import tweepy
import logging
print("🧪 تست اتصال توییتر...")
print("✅ ماژول tweepy بارگذاری شد")
print("✅ بات آماده اجرا")
print("💡 برای اتصال واقعی، کلیدهای API اضافه کنید")
EOF
    
    python3 test_bot.py
    rm test_bot.py
    print_status "✅ تست بات تکمیل شد"
}

# راه‌اندازی Docker (اختیاری)
setup_docker() {
    print_warning "آیا می‌خواهید Docker راه‌اندازی شود؟ [y/N]"
    read -r docker_choice
    
    if [[ $docker_choice =~ ^[Yy]$ ]]; then
        print_status "راه‌اندازی Docker..."
        
        # بررسی Docker
        if ! command -v docker &> /dev/null; then
            print_error "Docker نصب نیست!"
            print_warning "لطفاً ابتدا Docker نصب کنید"
            return
        fi
        
        # ساخت ایمیج
        docker-compose build
        
        # اجرای کانتینرها
        docker-compose up -d
        
        # انتظار برای آماده شدن
        sleep 10
        
        # تست سلامت
        if curl -f http://localhost:8080/health > /dev/null 2>&1; then
            print_status "✅ Docker راه‌اندازی شد"
            print_status "🌐 پنل در: http://localhost:8080"
        else
            print_error "خطا در راه‌اندازی Docker"
        fi
    fi
}

# راه‌اندازی Local Server
start_local_server() {
    print_status "راه‌اندازی سرور محلی..."
    
    # فعال‌سازی محیط مجازی
    source venv/bin/activate
    
    # اجرای سرور
    log "شروع سرور Flask در پورت 5000"
    print_status "🌐 سرور در حال راه‌اندازی..."
    print_status "🌐 آدرس: http://localhost:5000"
    print_status "👤 ورود: admin@trendbot.ir / admin123"
    
    # اجرای Gunicorn برای Production
    if command -v gunicorn &> /dev/null; then
        gunicorn --workers 4 \
                 --bind 0.0.0.0:5000 \
                 --timeout 120 \
                 --log-level info \
                 --access-logfile logs/gunicorn_access.log \
                 --error-logfile logs/gunicorn_error.log \
                 wsgi:app
    else
        # Fallback به Flask development server
        python wsgi.py
    fi
}

# نمایش اطلاعات نهایی
show_final_info() {
    clear
    print_logo
    echo -e "${CYAN}"
    cat << EOF
    
    🎉  TREND BOT ULTIMATE با موفقیت راه‌اندازی شد!  🎉
    
    📋  اطلاعات ورود:
    ┌─────────────────────────────────────┐
    │ ایمیل: admin@trendbot.ir            │
    │ رمز عبور: admin123                 │
    └─────────────────────────────────────┘
    
    🌐  آدرس‌های دسترسی:
    ┌─────────────────────────────────────┐
    │ پنل اصلی:    http://localhost:5000  │
    │ اکانت‌ها:    http://localhost:5000/accounts │
    │ هشتگ‌ها:     http://localhost:5000/hashtags │
    │ آمار:        http://localhost:5000/analytics │
    └─────────────────────────────────────┘
    
    🛠  دستورات مفید:
    ┌─────────────────────────────────────┐
    │ مشاهده لاگ:  tail -f logs/*.log     │
    │ توقف سرور:   Ctrl+C                │
    │ Docker:      docker-compose up -d   │
    │ بکاپ:        python backup.py       │
    └─────────────────────────────────────┘
    
EOF
    echo -e "${NC}"
}

# تابع اصلی
main() {
    print_logo
    log "شروع راه‌اندازی $PROJECT_NAME"
    
    check_os
    create_directories
    install_system_deps
    install_python_deps
    setup_database
    test_twitter_bot
    
    echo -e "${YELLOW}"
    echo "🎯 انتخاب روش راه‌اندازی:"
    echo "1️⃣  Local Server (توصیه شده)"
    echo "2️⃣  Docker Compose"
    echo "3️⃣  فقط تست"
    echo -n "انتخاب کنید [1]: "
    read -r choice
    
    case $choice in
        2)
            setup_docker
            ;;
        3)
            print_status "تست تکمیل شد!"
            show_final_info
            exit 0
            ;;
        *)
            start_local_server
            ;;
    esac
    
    show_final_info
}

# اجرای اصلی
main "$@"