from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required
from models import Hashtag
from database import db
import logging

hashtags_bp = Blueprint('hashtags', __name__)
logger = logging.getLogger(__name__)

@hashtags_bp.route('/')
@login_required
def index():
    """Hashtags management page"""
    try:
        hashtags = Hashtag.query.order_by(Hashtag.created_at.desc()).all()
        return render_template('hashtags.html', hashtags=hashtags)
    except Exception as e:
        logger.error(f"Hashtags index error: {str(e)}")
        flash('خطا در بارگذاری هشتگ‌ها', 'error')
        return render_template('hashtags.html', hashtags=[])

@hashtags_bp.route('/add', methods=['POST'])
@login_required
def add():
    """Add new hashtag"""
    try:
        tag = request.form.get('tag', '').strip()
        
        if not tag:
            flash('هشتگ نمی‌تواند خالی باشد', 'error')
            return redirect(url_for('hashtags.index'))
        
        # Clean hashtag
        tag = tag.replace('#', '').strip()
        if not tag:
            flash('هشتگ نامعتبر است', 'error')
            return redirect(url_for('hashtags.index'))
        
        # Check if exists
        existing = Hashtag.query.filter_by(tag=tag).first()
        if existing:
            flash(f'هشتگ #{tag} قبلاً اضافه شده است', 'warning')
            return redirect(url_for('hashtags.index'))
        
        # Create hashtag
        hashtag = Hashtag(
            tag=tag,
            interactions=0,
            is_active=True
        )
        
        db.session.add(hashtag)
        db.session.commit()
        
        logger.info(f"Hashtag added: #{tag}")
        flash(f'هشتگ #{tag} با موفقیت اضافه شد ✅', 'success')
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Hashtag add error: {str(e)}")
        flash('خطا در اضافه کردن هشتگ', 'error')
    
    return redirect(url_for('hashtags.index'))

@hashtags_bp.route('/<int:hashtag_id>/delete', methods=['POST'])
@login_required
def delete(hashtag_id):
    """Delete hashtag"""
    try:
        hashtag = Hashtag.query.get_or_404(hashtag_id)
        tag_name = hashtag.tag
        
        db.session.delete(hashtag)
        db.session.commit()
        
        logger.info(f"Hashtag deleted: #{tag_name}")
        flash(f'هشتگ #{tag_name} حذف شد ✅', 'success')
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Hashtag deletion error: {str(e)}")
        flash('خطا در حذف هشتگ', 'error')
    
    return redirect(url_for('hashtags.index'))

@hashtags_bp.route('/api/popular')
@login_required
def popular_hashtags():
    """API for popular hashtags suggestions"""
    try:
        popular = [
            'ایران', 'تهران', 'فوتبال', 'بورس', 'ارزدیجیتال',
            'بیتکوین', 'اقتصاد', 'سیاست', 'تکنولوژی', 'آموزش'
        ]
        
        return jsonify({
            'success': True,
            'data': popular
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@hashtags_bp.route('/stats')
@login_required
def hashtags_stats():
    """API for hashtags statistics"""
    try:
        hashtags = Hashtag.query.all()
        stats = []
        
        for hashtag in hashtags:
            stats.append({
                'id': hashtag.id,
                'tag': hashtag.tag,
                'interactions': hashtag.interactions,
                'is_active': hashtag.is_active,
                'created_at': hashtag.created_at.isoformat()
            })
        
        return jsonify({
            'success': True,
            'data': stats,
            'summary': {
                'total': len(hashtags),
                'active': len([h for h in hashtags if h.is_active])
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500