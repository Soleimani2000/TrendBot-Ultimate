# Twitter Bot 
import tweepy
import time
import random
import logging
from datetime import datetime, date
import os
from models import db, TwitterAccount, Hashtag, ProcessedTweet
from sqlalchemy.orm import sessionmaker

# تنظیم لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler('logs/bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RealTwitterBot:
    def __init__(self):
        self.bearer_token = os.getenv('TWITTER_BEARER_TOKEN')
        self.consumer_key = os.getenv('TW_CONSUMER_KEY')
        self.consumer_secret = os.getenv('TW_CONSUMER_SECRET')
        
    def create_client(self, account):
        """ایجاد کلاینت توییتر واقعی"""
        try:
            client = tweepy.Client(
                bearer_token=self.bearer_token,
                consumer_key=self.consumer_key,
                consumer_secret=self.consumer_secret,
                access_token=account.access_token,
                access_token_secret=account.access_token_secret,
                wait_on_rate_limit=True
            )
            
            # تست اتصال
            me = client.get_me()
            logger.info(f"✅ اتصال موفق: {account.name}")
            return client
            
        except Exception as e:
            logger.error(f"❌ خطای اتصال {account.name}: {e}")
            return None

    def search_tweets(self, client, hashtag):
        """جستجوی توییت‌های جدید"""
        try:
            query = f"#{hashtag} lang:fa -is:retweet -is:reply"
            response = client.search_recent_tweets(
                query=query,
                max_results=10,
                tweet_fields=['id']
            )
            
            tweets = []
            if response.data:
                for tweet in response.data:
                    # چک تکراری
                    if not ProcessedTweet.query.filter_by(
                        tweet_id=str(tweet.id),
                        account_id=client.account_id  # این خط رو در کلاینت ست کن
                    ).first():
                        tweets.append(str(tweet.id))
            
            logger.info(f"🔍 #{hashtag}: {len(tweets)} توییت جدید")
            return tweets[:5]
            
        except Exception as e:
            logger.error(f"❌ خطای جستجو #{hashtag}: {e}")
            return []

    def like_tweet(self, client, tweet_id, account, hashtag):
        """لایک واقعی"""
        try:
            client.like(tweet_id)
            
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=account.id,
                hashtag=hashtag,
                action='like',
                success=True
            )
            db.session.add(processed)
            account.likes_today += 1
            account.last_active = datetime.now()
            db.session.commit()
            
            logger.info(f"❤️ لایک موفق | {account.name}")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطای لایک: {e}")
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=account.id,
                hashtag=hashtag,
                action='like',
                success=False,
                error_message=str(e)
            )
            db.session.add(processed)
            db.session.commit()
            return False

    def retweet_tweet(self, client, tweet_id, account, hashtag):
        """ریتوییت واقعی"""
        try:
            client.retweet(tweet_id)
            
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=account.id,
                hashtag=hashtag,
                action='retweet',
                success=True
            )
            db.session.add(processed)
            account.retweets_today += 1
            account.last_active = datetime.now()
            db.session.commit()
            
            logger.info(f"🔄 ریتوییت موفق | {account.name}")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطای ریتوییت: {e}")
            processed = ProcessedTweet(
                tweet_id=tweet_id,
                account_id=account.id,
                hashtag=hashtag,
                action='retweet',
                success=False,
                error_message=str(e)
            )
            db.session.add(processed)
            db.session.commit()
            return False

    def reset_daily_stats(self):
        """ریست آمار روزانه"""
        today = date.today()
        accounts = TwitterAccount.query.all()
        
        for account in accounts:
            if account.last_active and account.last_active.date() < today:
                account.likes_today = 0
                account.retweets_today = 0
        
        db.session.commit()
        logger.info("✅ آمار روزانه ریست شد")

    def run(self):
        """اجرای اصلی بات"""
        logger.info("🤖 TrendBot Ultimate v6.0 شروع شد!")
        logger.info("⏰ هر 5 دقیقه یک دور کامل")
        
        cycle = 0
        while True:
            try:
                cycle += 1
                logger.info(f"🚀 دور {cycle} شروع شد")
                
                # ریست آمار
                self.reset_daily_stats()
                
                # بارگذاری داده‌ها
                accounts = TwitterAccount.query.filter_by(is_active=True).all()
                hashtags = [h.tag for h in Hashtag.query.all()]
                
                logger.info(f"📊 {len(accounts)} اکانت | {len(hashtags)} هشتگ")
                
                if not accounts or not hashtags:
                    logger.warning("⚠️ اکانت یا هشتگ وجود ندارد!")
                    time.sleep(300)
                    continue

                total_actions = 0
                for account in accounts:
                    # چک محدودیت
                    if (account.likes_today >= account.max_likes_per_day and 
                        account.retweets_today >= account.max_retweets_per_day):
                        logger.info(f"⏹️ {account.name}: محدودیت پر")
                        continue
                    
                    client = self.create_client(account)
                    if not client:
                        continue
                    
                    # 3 هشتگ تصادفی
                    selected_hashtags = random.sample(hashtags, min(3, len(hashtags)))
                    
                    for hashtag in selected_hashtags:
                        tweet_ids = self.search_tweets(client, hashtag)
                        
                        for tweet_id in tweet_ids:
                            if account.likes_today >= account.max_likes_per_day:
                                break
                            
                            # 70% لایک، 30% ریتوییت
                            if random.random() < 0.7:
                                if self.like_tweet(client, tweet_id, account, hashtag):
                                    total_actions += 1
                            else:
                                if self.retweet_tweet(client, tweet_id, account, hashtag):
                                    total_actions += 1
                            
                            time.sleep(random.randint(30, 60))
                    
                    time.sleep(random.randint(60, 120))
                
                logger.info(f"✅ دور {cycle} کامل | {total_actions} تعامل")
                logger.info("💤 5 دقیقه صبر...")
                time.sleep(300)
                
            except KeyboardInterrupt:
                logger.info("🛑 بات متوقف شد")
                break
            except Exception as e:
                logger.error(f"💥 خطا: {e}")
                time.sleep(60)

if __name__ == "__main__":
    bot = RealTwitterBot()
    bot.run()