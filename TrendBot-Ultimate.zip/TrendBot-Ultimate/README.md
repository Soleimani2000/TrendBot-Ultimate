# 🚀 TrendBot Ultimate v2.0

## پنل مدیریت بات توییتر پیشرفته

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.8+-brightgreen.svg)](https://python.org)
[![Docker](https://img.shields.io/badge/Docker-Supported-blue.svg)](https://docker.com)
[![Flask](https://img.shields.io/badge/Flask-2.0+-green.svg)](https://flask.palletsprojects.com)

## ✨ ویژگی‌های کلیدی

| ویژگی | وضعیت |
|--------|--------|
| 🎨 **رابط کاربری مدرن** | ✅ Glassmorphism |
| ⚡ **فعالیت زنده** | ✅ Real-time |
| 📊 **چارت‌های پیشرفته** | ✅ Chart.js |
| 👥 **مدیریت اکانت** | ✅ نامحدود |
| 🏷️ **مدیریت هشتگ** | ✅ هوشمند |
| 📈 **آمار کامل** | ✅ تفصیلی |
| 🐳 **Docker Support** | ✅ Production |
| 🇮🇷 **زبان فارسی** | ✅ کامل |
| 📱 **Responsive** | ✅ موبایل/دسکتاپ |

## 🚀 راه‌اندازی سریع (5 دقیقه)

### روش 1: یک‌کلیکی (Windows)
```bash
# دانلود و استخراج
# اجرای تست
test.bat
# راه‌اندازی
start.bat